
import Board from "./components/Board";
import GameStatus from "./components/GameStatus";
import GameControls from "./components/GameControls";
import MoveHistory from "./components/MoveHistory";
import Scoreboard from "./components/Scoreboard";

import useGame, { GAME_MODES } from "./hooks/useGame";

import "./App.css";

function App() {
  const {
    board,
    currentPlayer,
    winner,
    winningCells,
    isDraw,
    history,
    gameMode,
    scores,

    handleCellClick,
    handleUndo,
    handleReset,
    handleResetScores,
    handleGameModeChange,

    canUndo,
  } = useGame();

  return (
    <div className="app">
      <div className="game-container">

        {/* Header */}
        <header className="game-header">
          <h1>Tic Tac Toe</h1>

          <p>
            Play with a friend or challenge the computer.
          </p>
        </header>

        {/* Game mode */}
        <section className="game-mode">
          <label htmlFor="gameMode">
            Game Mode
          </label>

          <select
            id="gameMode"
            value={gameMode}
            onChange={handleGameModeChange}
          >
            <option value={GAME_MODES.TWO_PLAYER}>
              Two Players
            </option>

            <option value={GAME_MODES.COMPUTER}>
              Play Against Computer
            </option>
          </select>
        </section>

        {/* Game status */}
        <GameStatus
          currentPlayer={currentPlayer}
          winner={winner}
          isDraw={isDraw}
          gameMode={gameMode}
        />

        {/* Board */}
        <Board
          board={board}
          onCellClick={handleCellClick}
          winningCells={winningCells}
        />

        {/* Game controls */}
        <GameControls
          onUndo={handleUndo}
          onReset={handleReset}
          canUndo={canUndo}
        />

        {/* Scoreboard */}
        <Scoreboard
          scores={scores}
          onResetScores={handleResetScores}
        />

        {/* Move history */}
        <MoveHistory history={history} />

        {/* Footer */}
        <footer className="game-footer">
          <p>
            {gameMode === GAME_MODES.COMPUTER
              ? "You are X. Computer is O."
              : "X and O take turns."}
          </p>
        </footer>

      </div>
    </div>
  );
}

export default App;
